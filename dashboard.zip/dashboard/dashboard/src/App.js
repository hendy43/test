import React, { Component } from 'react';
import './App.css';
import 'semantic-ui-css/semantic.min.css'
import { Route, Switch } from "react-router-dom";
import Header from './asd/components/header'
import Footer from './asd/components/footer'
import Dashboard from './asd/screens/dashboard'
import Detail from './asd/screens/detail'
import Home from './asd/screens/home'
import Table from './asd/screens/table'
import Dashboard2 from './asd/screens/dashboard2';


class App extends Component {
  render() {
    return (
      <div className="App">
        <Header/>
          <Switch>
            <Route exact path="/home" component={Home} />
            <Route path="/dashboard" component={Dashboard} /> 
            <Route path="/detail" component={Detail} />
            <Route path="/table" component={Table} />
            <Route path="/dashboard2" component={Dashboard2} />
          </Switch>
        <Footer/>
      </div>
    );
  }
}

export default App;
