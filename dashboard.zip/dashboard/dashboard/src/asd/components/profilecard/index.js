import React from 'react'
import { Card, Icon, Image, Grid, Reveal } from 'semantic-ui-react'


const CardExampleImageCard = () => (
    <Grid columns={3} divided style={{padding:"50px",display:"flex",justifyContent:"center"}}>
    <Grid.Row>
      <Grid.Column>
      <Card>
    <Reveal animated='rotate left' style={{marginLeft:"25%",marginBottom:"5%"}}>
        <Reveal.Content visible>
            <Image circular size='small' src='https://t1.daumcdn.net/cfile/tistory/991D1C425B6C356E37' />
        </Reveal.Content>
        <Reveal.Content hidden>
            <Image circular size='small' src='https://i.imgur.com/dLlQGPH.jpg' />
        </Reveal.Content>
    </Reveal>
        <Card.Content>
            <Card.Header>Jisoo</Card.Header>
            <Card.Meta>Debut in 8 August 2016</Card.Meta>
            <Card.Description>Jisoo is a K-pop Artist</Card.Description>
        </Card.Content>
    <Card.Content extra>
      <a>
        <Icon name='user' />
        999 Friends
      </a>
    </Card.Content>
  </Card>
      </Grid.Column>
      <Grid.Column>
      <Card>
      <Reveal animated='move up' style={{marginLeft:"25%"}}>
        <Reveal.Content visible>
            <Image circular size='small' src='https://i.redd.it/rl9nc9eiuoz11.jpg' />
        </Reveal.Content>
        <Reveal.Content hidden style={{paddingRight:"33%"}}>
            <Image circular size='small' src='https://i.pinimg.com/originals/30/97/fb/3097fb6303d9a3bc411b8111d1a46934.jpg' />
        </Reveal.Content>
    </Reveal>
        <Card.Content>
            <Card.Header>Jisoo</Card.Header>
            <Card.Meta>Debut in 8 August 2016</Card.Meta>
            <Card.Description>Jisoo is a K-pop Artist</Card.Description>
        </Card.Content>
    <Card.Content extra>
      <a>
        <Icon name='user' />
        999 Friends
      </a>
    </Card.Content>
  </Card>
      </Grid.Column>
      <Grid.Column>
      <Card>
      <Reveal animated='rotate' style={{marginLeft:"25%",marginBottom:"10%"}}>
        <Reveal.Content visible>
            <Image circular size='small' src='https://data.whicdn.com/images/305731478/large.jpg' />
        </Reveal.Content>
        <Reveal.Content hidden>
            <Image circular size='small' src='https://i.pinimg.com/564x/95/53/ea/9553eab74de2739e444958dc1a050478.jpg' />
        </Reveal.Content>
    </Reveal>
        <Card.Content>
            <Card.Header>Jisoo</Card.Header>
            <Card.Meta>Debut in 8 August 2016</Card.Meta>
            <Card.Description>Jisoo is a K-pop Artist</Card.Description>
        </Card.Content>
    <Card.Content extra>
      <a>
        <Icon name='user' />
        999 Friends
      </a>
    </Card.Content>
  </Card>
      </Grid.Column>
    </Grid.Row>
  </Grid>
  
  

)

export default CardExampleImageCard
