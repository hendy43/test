import React, { Component, createRef } from 'react'
import {
  Button,
  Header,
  Radio,
  Menu,
  Ref,
  Segment,
  Sidebar,
  Icon,
  Container,
  Grid,
  Embed
} from 'semantic-ui-react'
import Profilecard from '../../components/profilecard'

export default class VisibilityExampleTarget extends Component {
  state = {}
  segmentRef = createRef()

  handleHideClick = () => this.setState({ visible: false })
  handleShowClick = () => this.setState({ visible: true })

  handleSidebarHide = () => this.setState({ visible: false })

  render() {
    const { visible } = this.state

    return (
      <div>
        <Ref innerRef={this.segmentRef}>
        <Sidebar.Pushable as={Segment.Group} raised>
        <Button.Group>
                <Button disabled={visible} onClick={this.handleShowClick} animated type='submit'>
                    <Button.Content visible>Show sidebar</Button.Content>
                    <Button.Content hidden>
                    <Icon name='arrow alternate circle left outline' />
                    </Button.Content>
                    </Button>
                    <Button disabled={!visible} onClick={this.handleHideClick} animated type='submit'>
                    <Button.Content visible>Hide sidebar</Button.Content>
                    <Button.Content hidden>
                    <Icon name='arrow alternate circle right outline' />
                    </Button.Content>
                </Button>    
        </Button.Group>
        <Profilecard/>
        <Container className="ContainerDashboard">
               <Segment>           
               <Grid>
                    <Grid.Row>
                    <Grid.Column width={8}>
        <iframe src="https://open.spotify.com/embed/user/hendy4343/playlist/5MBNILaHSp1BkUR4W8kq4D" 
            width="300" height="380" frameborder="0" allowtransparency="true" 
            allow="encrypted-media">
            </iframe>
                    </Grid.Column>
                    <Grid.Column width={8}>
                    <Embed aspectRatio="4:3" id='2S24-y0Ij3Y' 
    placeholder='https://i.pinimg.com/originals/30/97/fb/3097fb6303d9a3bc411b8111d1a46934.jpg' 
    source='youtube' style={{marginTop:"40px"}} />
                    </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Segment>
               </Container>
          <Sidebar
            as={Menu}
            animation='overlay'
            icon='labeled'
            inverted
            onHide={this.handleSidebarHide}
            vertical
            target={this.segmentRef}
            visible={visible}
            width='thin'
          >
            <Menu.Item as='a' href='Home'>Home</Menu.Item>
            <Menu.Item as='a' href='Dashboard'>Dashboard</Menu.Item>
            <Menu.Item as='a' href='Detail'>Form</Menu.Item>
            <Menu.Item as='a' href='Table'>Table</Menu.Item>
            <Menu.Item as='a' href='Dashboard2'>Dashboard 2</Menu.Item>
          </Sidebar>


          <Segment>
            <Header as='h3'>Application Content</Header>
            <p>
              – Jisoo was born in Seoul, South Korea.
              – She has an older brother and an older sister, she is the youngest.
              – She trained for 5 years (since July 2011).
              – Jisoo’s Chinese zodiac sign is Dog.
              – She has a 4D personality. XD
              – She laughs a lot.
              – She likes giving random nicknames to people.
              – According to Jennie, Jisoo is the mood maker of the group.
              – Jsoo loves telling dad Jokes (Vlive)
              – Jisoo invented the word “yeong-an” which means “anyoeong” (and is the reverse form of it).
              – Jisoo can play the drums.
              – Jisoo can play piano but not the guitar (in a vlive with Rosé she told Rosé to teach her).
              – She can speak Korean, Japanese and basic Chinese.
              – According to Jennie (V Live App), Jisoo doesn’t speak English (because she’s embarrassed to do it) but she can understand it very well.
              – Jisoo was popular in her school for her beauty and kindness.
              – Jisoo’s audition song was “I Have A Lover” by Lee Eun Mi.
              – Jisoo is scared of heights.
              – Jisoo would date Rose if she was a guy. (vLive Q&A)
              – Jisoo’s lips turn into a heart shape when she smiles.
              – Jisoo’s most favorite part of her face are her lips. (vLive Q&A)
              – Jisoo hates shopping because she is often confused what to buy. (BP House)
              – She is close friends with Twice’s Nayeon (since trainee days) and with Red Velvet’s Seulgi.
              – Jisoo invented two words: Ppoong and Nyeongan
              – Jisoo was an Inkigayo MC (starting from Feb 5 2017 to Feb 3 2018) alongside GOT7’s Jinyoung and NCT’s Doyoung.
              – She had a cameo appearance on KBS’s ‘The Producers’ (2015).
              – She acted in HISUHYUN’s ‘I’m Different’ MV.
              – Jisoo acted in EPIK HIGH – ‘스포일러(SPOILER) + 헤픈엔딩(HAPPEN ENDING)’ M/V.
              – She appeared in different CFs such as SAMSONITE RED CF with Lee Minho (2015), Nikon 1 J5 CF (2015), SMART UNIFORM CF with iKON (2015), Angel Stone CF (2015), SMART UNIFORM CF with iKON (2016), LG Stylus2 CF (2016).
              – Jisoo really likes Pikachu (she has a lot of Pikachu merchandise).
              – Jisoo sleeps with a plushie of a bunny and a plushie of Snoopy.
              – IKON members said she has the brightest smile.
              – Jisoo is well known for being the only member that hasn’t cried at award shows, but one of the other members said that she cries alone.
              – Regarding food, she can eat almost everything (except organs XD), but she especially likes rice.
              – Jisoo has a dog named Dalgom.
              – Jisoo called Lisa her ‘Chocolate mate’ because Lisa gave her iced chocolate during a live show (which Jisoo was craving) but Jisoo didn’t ask her to get it for her.
              – Jisoo can play basketball and inline skates but she can’t ride bicycles.
              – Also, she did taekwondo (white belt).
              – She said she plays “Overwatch” with Jennie.
              – She is not scared on ghost or scary stories.
              – She likes Harry Potter and Tom Hardy.
              – Jisoo’s favourite singer/band is TVXQ. (“Knowing Bros”)
              – She also likes to read manga as she keeps a stack of them near her bed to help her sleep. (V-live)
              – She loves the color purple. (According to what she said on their Comeback V Live)
              – She’s a PC Gamer. (BLACKPINK House EP.1-2)
              – Kim Samuel publicly confessed that he has a crush on Jisoo.
              – Jisoo is called “Man Heart’s Destroyer” and “Boy Crush”.
              – BigBang’s Seungri said that Jisoo reminds him of T.O.P, who is random and unpredictable but also charismatic.
              – Jisoo’s ideal type: someone who is really into her or who smiles pretty.
             </p>
          </Segment>

        <Radio toggle onClick={this.handleShowClick} /> 
        </Sidebar.Pushable>
        </Ref>
      </div>
    )
  }
}
