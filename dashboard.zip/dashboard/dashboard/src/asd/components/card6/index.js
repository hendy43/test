import React from 'react'
import { Card, Table,Dropdown, Menu, Button } from 'semantic-ui-react'

const options = [
  { key: 1, text: 'Receivable', value: 1 },
  { key: 2, text: 'Payable', value: 2 },
  { key: 3, text: 'Forex Rate', value: 3 },
]

const CardExampleCard = () => (
    <Card fluid className="Cards">
      <Card.Content className="ContentHeader">
      <Card.Header className="HeaderCard">Payables</Card.Header>
      <Button circular icon='x' style={{float:"right"}}/>
     </Card.Content>
      <Card.Content>
      <p style={{float:"left"}}>
            Number of Transactions ()
        </p>
        <p style={{float:"right"}}>
            Total Amount ()
        </p>
      <Table fixed floated='left'>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell style={{color:"blue"}}>Description</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Amount</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Beneficiary</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Due</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>eInvoice</Table.Cell>
        <Table.Cell>IDR 50,000,000</Table.Cell>
        <Table.Cell>PT. ABC</Table.Cell>
        <Table.Cell>21-Jan-14</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Single Transfer</Table.Cell>
        <Table.Cell>USD 800</Table.Cell>
        <Table.Cell>John Lenon</Table.Cell>
        <Table.Cell>1-Mar-14</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Bill Payment</Table.Cell>
        <Table.Cell>IDR 2,000,000</Table.Cell>
        <Table.Cell>Telkomsel</Table.Cell>
        <Table.Cell>30-Mar-14</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Incoming Cheque</Table.Cell>
        <Table.Cell>IDR 10,000,000</Table.Cell>
        <Table.Cell>PT. XYZ</Table.Cell>
        <Table.Cell>5-Apr-14</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Tax Payment</Table.Cell>
        <Table.Cell>IDR 8,700,000</Table.Cell>
        <Table.Cell>DJP</Table.Cell>
        <Table.Cell>5-Apr-14</Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
  <Menu compact floated='left'>
    <Dropdown text='Create Payable' options={options} simple item />
  </Menu>
  <a style={{float:"right"}} href="#">
     View More
  </a>
      </Card.Content>
    </Card>
 
)

export default CardExampleCard