import React, { PureComponent } from 'react';
import { Card, Dropdown, Menu, Table, Button } from 'semantic-ui-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';
import axios from 'axios';

const options = [
  { key: 1, text: 'Receivable', value: 1 },
  { key: 2, text: 'Payable', value: 2 },
  { key: 3, text: 'Forex Rate', value: 3 },
]

const data = [
  {
    name: 'Sep-13', CashIn: 430000, CashOut: 320000, amt: 2400,
  },
  {
    name: 'Oct-13', CashIn: 500000, CashOut: 380000, amt: 2210,
  },
  {
    name: 'Nov-13', CashIn: 69000, CashOut: 100000, amt: 2290,
  },
  {
    name: 'Dec-13', CashIn: 290000, CashOut: 150000, amt: 2000,
  },
  {
    name: 'Jan-14', CashIn: 900000, CashOut: 400000, amt: 2181,
  },
  {
    name: 'Feb-14', CashIn: 530000, CashOut: 230000, amt: 2500,
  }
];

export default class Example extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
       data: []
    }
 }

componentDidMount() {
  axios.get('https://my-json-server.typicode.com/hendy43/test/db')
    .then(response => {
        if (response.status === 200 && response != null) {
          this.setState({
               data: response.data
          });
   } else {
     console.log('problem');
   }
})
.catch(error => {
  console.log(error);
});
}

  static jsfiddleUrl = 'https://jsfiddle.net/alidingling/30763kr7/';

  render() {
    // const { data } = this.state;
    return (
      <Card fluid className="Cards">
      <Card.Content className="ContentHeader">
      <Card.Header className="HeaderCard">
      Profit and Loss
      </Card.Header>
      <Button circular icon='x' style={{float:"right"}}/>
      </Card.Content>
        <Card.Content>
        <BarChart
        width={400}
        height={300}
        data={data}
        margin={{
          top: 5, right: 70, left: 20, bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="CashIn" fill="#0088FE" />
        <Bar dataKey="CashOut" fill="#FF8042" />
      </BarChart>
      </Card.Content>
      <Card.Content>
      <Table definition>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell />
        <Table.HeaderCell>Sep-13</Table.HeaderCell>
        <Table.HeaderCell>Oct-13</Table.HeaderCell>
        <Table.HeaderCell>Nov-13</Table.HeaderCell>
        <Table.HeaderCell>Dec-13</Table.HeaderCell>
        <Table.HeaderCell>Jan-14</Table.HeaderCell>
        <Table.HeaderCell>Feb-14</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>Cash In</Table.Cell>
        <Table.Cell>430,000</Table.Cell>
        <Table.Cell>500,000</Table.Cell>
        <Table.Cell>69,000</Table.Cell>
        <Table.Cell>290,000</Table.Cell>
        <Table.Cell>900,000</Table.Cell>
        <Table.Cell>530,000</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Cash Out</Table.Cell>
        <Table.Cell>320,000</Table.Cell>
        <Table.Cell>380,000</Table.Cell>
        <Table.Cell>100,000</Table.Cell>
        <Table.Cell>150,000</Table.Cell>
        <Table.Cell>400,000</Table.Cell>
        <Table.Cell>230,000</Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
      </Card.Content>
      <Card.Content>
      <Menu compact floated='left'>
        <Dropdown text='Financial Report' options={options} simple item />
      </Menu>
      <a style={{float:"right"}} href="#">
       View Detail
      </a>
      </Card.Content>

    </Card>

    );
  }
}
