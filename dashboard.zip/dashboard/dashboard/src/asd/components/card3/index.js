import React from 'react'
import { Card, Button, Icon } from 'semantic-ui-react'

const CardExampleCard = () => (
  <Card fluid className="Cards">
      <Card.Content className="ContentHeader">
      <Card.Header className="HeaderCard">Most Visited</Card.Header>
      <Button circular icon='x' style={{float:"right"}}/>
     </Card.Content>
  <Card.Content>

    <Button circular size='medium' href="#">
      <Button.Content >
      <Icon name='user circle' />
      </Button.Content>
      Profile
    </Button>

    <Button circular size='medium' href="#">
      <Button.Content> 
      <Icon name='clipboard list' />
      </Button.Content>
      Account Summary
    </Button>


    <Button circular size='medium' href="#">
      <Button.Content>
        <Icon name='file alternate outline' />
      </Button.Content>
        Statement
    </Button>

    <Button circular size='medium' href="#">
      <Button.Content>
        <Icon name='chart line' />
      </Button.Content>
        In-House Transfer
    </Button>
  </Card.Content>
</Card>
 
)

export default CardExampleCard