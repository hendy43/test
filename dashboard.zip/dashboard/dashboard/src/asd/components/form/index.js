import React from 'react'
import { Button, Checkbox, Form, Icon, Container } from 'semantic-ui-react'

const FormExampleForm = () => (
 <Container fluid className="FormContainer">
 <Form>
    <Form.Field>
      <label>First Name</label>
      <input placeholder='First Name' />
    </Form.Field>
    <Form.Field>
      <label>Last Name</label>
      <input placeholder='Last Name' />
    </Form.Field>
    <Form.Field>
      <label>E-Mail</label>
      <input placeholder='E-Mail' />
    </Form.Field>
    <Form.Field>
      <label>Phone Number</label>
      <input placeholder='Phone Number' />
    </Form.Field>
    <Form.Field>
      <label>Age</label>
      <input placeholder='Age' />
    </Form.Field>
    <Form.Field>
      <Checkbox label='I agree to the Terms and Conditions' />
    </Form.Field>
    <Button animated type='submit'>
      <Button.Content visible>Submit</Button.Content>
      <Button.Content hidden>
        <Icon name='thumbs up outline' />
      </Button.Content>
    </Button>
  </Form>
  </Container>
)

export default FormExampleForm
