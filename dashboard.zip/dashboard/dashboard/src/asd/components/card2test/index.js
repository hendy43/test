import React, { PureComponent } from 'react';
import { Card } from 'semantic-ui-react'
import DonutChart from 'react-donut-chart';

        const CardExampleCard = () => (
            <Card fluid className="Cards">
            <Card.Content className="ContentHeader">
            <Card.Header className="HeaderCard">
            Account Overview
            </Card.Header>
            </Card.Content>
            <Card.Content>
            <DonutChart className="DonutChart" width={200} height={150}
                data={[
                    {
                        label: 'Assets(My Bank)',
                        value: 73
                    },
                    {
                    label: 'Assets(External Bank)',
                    value: 27
                }
                ]} />
            </Card.Content>
            <p style={{float:"left"}}>
                  As of 20 February 2014
              </p>
            <Card.Content> 
            <DonutChart className="DonutChart" width={200} height={150}
                data={[
                    {
                        label: 'Liabilities(Loan)',
                        value: 89,
                        
                    },
                    {
                    label: 'Liabilities(Credit Card)',
                    value: 11
                }
                ]} />
            <p style={{float:"left"}}>
                  As of 20 February 2014
              </p>
            </Card.Content>
          </Card>
           
          )
          
          export default CardExampleCard


        
