import React, { Component } from 'react'
import { Icon, Menu, Container, Divider } from 'semantic-ui-react'

export default class MenuExampleVertical extends Component {
  state = { activeItem: 'inbox' }

  handleItemClick = (e, { name }) => this.setState({ activeItem: name })

  render() {
    const { activeItem } = this.state

    return (
        <Menu secondary className="FooterMenu">
      <Container> 
       <Menu.Item 
        href='Home'
        name='home' 
        active={activeItem === 'home'} 
        onClick={this.handleItemClick} 
        >
         <Icon name='playstation' />
        </Menu.Item>
        <Menu.Item
          href='Dashboard'
          name='dashboard'
          active={activeItem === 'dashboard'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          href="Detail"
          name='detail'
          active={activeItem === 'detail'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          href="Table"
          name='table'
          active={activeItem === 'table'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          href="Dashboard2"
          name='dashboard2'
          active={activeItem === 'dashboard2'}
          onClick={this.handleItemClick}
        />
        </Container>
      </Menu>

    )
  }
}
