import React from 'react'
import { Card, Image, Icon } from 'semantic-ui-react'
import Clock from '../clock'

const CardExampleCard = () => (
    <Card fluid className="Cards">
      <Card.Content style={{textAlign:"left"}}>
        <Image floated='left' size='tiny' src='https://data.whicdn.com/images/305731478/large.jpg' rounded />
        <Card.Header>PT. Wirecard Technologies Indonesia, 
        <br/>Welcome Kim Jisoo</Card.Header>
        <Clock/>
        <a href="#">
        <Icon name='mail outline'/> 1 new Messages
        </a>
        <br />
        <a href="#">
        <Icon name='hourglass half'/> 3 Pending Task
        </a>
      </Card.Content>
    </Card>
 
)

export default CardExampleCard