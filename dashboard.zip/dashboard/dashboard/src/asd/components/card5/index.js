import React from 'react'
import { Card, Table,Dropdown, Menu, Button } from 'semantic-ui-react'

const options = [
  { key: 1, text: 'Receivable', value: 1 },
  { key: 2, text: 'Payable', value: 2 },
  { key: 3, text: 'Forex Rate', value: 3 },
]

const CardExampleCard = () => (
    <Card fluid className="Cards">
      <Card.Content className="ContentHeader">
      <Card.Header className="HeaderCard">Receivables</Card.Header>
      <Button circular icon='x' style={{float:"right"}}/>
     </Card.Content>
      <Card.Content>
        <p style={{float:"left"}}>
            Number of Transactions ()
        </p>
        <p style={{float:"right"}}>
            Total Amount ()
        </p>
      <Table fixed floated='left'>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell style={{color:"blue"}}>Description</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Amount</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Due</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>PT. ABC</Table.Cell>
        <Table.Cell>IDR 50,000,000</Table.Cell>
        <Table.Cell negative>
          21-Jan-14
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Corporate ltd</Table.Cell>
        <Table.Cell>USD 1,000</Table.Cell>
        <Table.Cell>
         1-Mar-14
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>PT. Company Indonesia</Table.Cell>
        <Table.Cell>IDR 89,000,000</Table.Cell>
        <Table.Cell>
          30-Mar-14
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Incoming Cheque</Table.Cell>
        <Table.Cell>IDR 10,000,000</Table.Cell>
        <Table.Cell>
          15-Apr-14
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Autodebit</Table.Cell>
        <Table.Cell>IDR 8,700,000</Table.Cell>
        <Table.Cell>
         15-Apr-14
        </Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
  
  <Menu compact floated='left'>
    <Dropdown text='Create Receivables' options={options} simple item />
  </Menu>
  <a style={{float:"right"}} href="#">
     View More
  </a>
      </Card.Content>
    </Card>
 
)

export default CardExampleCard