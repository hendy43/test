import React, { Component } from 'react'
import { Input, Menu, Icon, Container } from 'semantic-ui-react'

export default class MenuExampleSecondary extends Component {
  state = { activeItem: 'home' }

  handleItemClick = ({ name }) => this.setState({ activeItem: name })

  render() {
    const { activeItem } = this.state

    return (
      <Menu secondary className="HeaderMenu" >
            <Container>
        <Menu.Item 
        href='Home'
        name='home' 
        active={activeItem === 'home'} 
        onClick={this.handleItemClick} 
        >
         <Icon name='playstation' />
        </Menu.Item>
        <Menu.Item
          href='Dashboard'
          name='dashboard'
          active={activeItem === 'dashboard'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          href="Detail"
          name='detail'
          active={activeItem === 'detail'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          href="Table"
          name='table'
          active={activeItem === 'table'}
          onClick={this.handleItemClick}
        />
        <Menu.Item
          href="Dashboard2"
          name='dashboard2'
          active={activeItem === 'dashboard2'}
          onClick={this.handleItemClick}
        />
        <Menu.Menu position='right'>
          <Menu.Item>
          <Input icon={<Icon name='search' inverted circular link />} placeholder='Search...' />
          </Menu.Item>
          <Menu.Item
            name='logout'
            active={activeItem === 'logout'}
            onClick={this.handleItemClick}
          >
          <Icon name='sign-out' size='large'/>
          Sign Out
          </Menu.Item>
        </Menu.Menu>
        </Container>
      </Menu>
    )
  }
}
