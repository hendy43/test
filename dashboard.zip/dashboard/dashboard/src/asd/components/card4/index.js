import React from 'react'
import { Card, Table, Button } from 'semantic-ui-react'

const CardExampleCard = () => (
    <Card fluid className="Cards">
    <Card.Content className="ContentHeader">
     <Card.Header className="HeaderCard">Forex Rate</Card.Header>
     <Button circular icon='x' style={{float:"right"}}/>
     </Card.Content>
      <Card.Content>
      <p style={{float:"left"}}>
            As of 20 February 2014
        </p>
      <Table fixed floated='left'>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell style={{color:"blue"}}>Currency</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Buy</Table.HeaderCell>
        <Table.HeaderCell style={{color:"blue"}}>Sell</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>USD</Table.Cell>
        <Table.Cell>14.000</Table.Cell>
        <Table.Cell>
          13.500
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>SGD</Table.Cell>
        <Table.Cell>9.500</Table.Cell>
        <Table.Cell>
         9.000
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>EUR</Table.Cell>
        <Table.Cell>16.000</Table.Cell>
        <Table.Cell>
          15.500
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>AUD</Table.Cell>
        <Table.Cell>13.000</Table.Cell>
        <Table.Cell>
          12.500
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>JPY</Table.Cell>
        <Table.Cell>130</Table.Cell>
        <Table.Cell>
         120
        </Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
</Card.Content>
</Card>
)

export default CardExampleCard