import React,{ Component } from 'react'

class Home extends Component{
    render() {
        return(
            <div>
                INI HALAMAN HOME
            </div>
        )
    }
}

export default Home