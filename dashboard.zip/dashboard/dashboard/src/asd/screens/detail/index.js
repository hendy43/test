import React,{ Component } from 'react'
import Form from '../../components/form'

class Detail extends Component{
    render() {
        return(
            <div>
                <Form/>
            </div>
        )
    }
}

export default Detail