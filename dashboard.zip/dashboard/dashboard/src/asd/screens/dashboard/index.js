import React,{ Component } from 'react'
import Sidebar from '../../components/sidebar'

class Dashboard extends Component{
    render() {
        return(
           <div>
               <Sidebar/>
            </div>
        )
    }
}

export default Dashboard