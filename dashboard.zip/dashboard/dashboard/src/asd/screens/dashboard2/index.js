import React,{ Component } from 'react'
import { Segment, Container, Grid, Card, Icon} from 'semantic-ui-react';
import Clock from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/clock'
import Card1 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card1'
import Card2 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card2'
import Card3 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card3'
import Card4 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card4'
import Card5 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card5'
import Card6 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card6'
import Card7 from '/Users/user/Desktop/dashboard/dashboard/src/asd/components/card7'


class Dashboard2 extends Component{
    render() {
        return(
           <div>
                <Container className="AtasanDashboard" >
                   <Card fluid>
                   <Card.Content>
                       <Card.Header>
                       <a style={{float:"right"}} href="#">
                   <Icon name='settings'/> Customize Dashboard
                   </a>
                    <div style={{float:"left"}}>
                   Dashboard
                   </div>
                   <br/>
                   <div style={{float:"left"}}>
                   <Clock/>
                   </div>

                   </Card.Header>

                    </Card.Content>
                   </Card>
               </Container>
               <Container className="ContainerDashboard">
               <Segment>           
               <Grid>
                    <Grid.Row>
                    <Grid.Column width={8}>
                        <Card1/>
                        <Card2/>
                        <Card3/>
                        <Card4/>
                    </Grid.Column>
                    <Grid.Column width={8}>
                        <Card5/>
                        <Card6/>
                        <Card7/>
                    </Grid.Column>
                    </Grid.Row>

                </Grid>
                </Segment>
               </Container>
            </div>
        )
    }
}

export default Dashboard2