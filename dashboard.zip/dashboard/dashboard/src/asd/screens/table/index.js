import React,{ Component } from 'react'
import Table from '../../components/table'

class Tables extends Component{
    render() {
        return(
            <div>
            <Table/>
            </div>
        )
    }
}

export default Tables