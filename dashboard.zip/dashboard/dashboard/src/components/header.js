import React from 'react';
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import logo from '/Users/user/Desktop/dashboard/dashboard/src/img/logologin.jpg';

class Header extends React.Component {
    render() {
        return (
            <div className="HeaderRow">
            <Row className="HeaderText"> 
              <Col sm={6}>Wirecard</Col>
              <Col sm={1}>Jeremy Brown</Col>
              <Col sm={1}>LOGO</Col>
              <Col sm={1}>pin</Col>
              <Col sm={1}>Sign Out</Col>
            </Row>
            </div>
        )
    }
}


export default Header;