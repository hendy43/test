import React from 'react';
import {Navbar} from 'react-bootstrap';
import {Nav} from 'react-bootstrap';
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';


class Footer extends React.Component {
    render() {
        return (
          <div>
              <Navbar bg="light" variant="light" className="NavBarFooter">
              <Nav className="NavFooter">
              <Nav.Link href="My Tasks">Bahasa Indonesia</Nav.Link>
                <Nav.Link href="My Tasks">English</Nav.Link>
                <Nav.Link href="My Tasks" className="FooterNavRates">Rates</Nav.Link>
                <Nav.Link href="My Tasks">Terms & Conditions</Nav.Link>
                <Nav.Link href="My Tasks">Privacy Policy</Nav.Link>
                <Nav.Link href="My Tasks">Help</Nav.Link>
                <Nav.Link href="My Tasks">Contact Us</Nav.Link>

              </Nav>
              </Navbar>

              <Row className="FooterBawahText"> 
              <Col sm={1}>Wirecard</Col>
              <Col sm>MyBank Internet Business is Service mark of PT.MyBank, Tbk<br></br>
                        Lorem Ipsum dolor sit amet consecteur adspicising elt sedo
              </Col>
              </Row>
            </div>
        )
    }
}



export default Footer;