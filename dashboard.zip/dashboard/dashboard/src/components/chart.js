import React from 'react';
import {Row, Jumbotron} from 'react-bootstrap';
import {Col} from 'react-bootstrap';


class Chart extends React.Component {
    render() {
        return (
            <div >
            <Row className="JumboChart">
            <Jumbotron className="Jumbo1" id="Jumbo1">
                <Col>
                test 1
                </Col>
            </Jumbotron>
            <Jumbotron className="Jumbo2">
                <Col>
                test 2
                </Col>
            </Jumbotron>
            </Row>
            </div>
        )
    }
}



export default Chart;